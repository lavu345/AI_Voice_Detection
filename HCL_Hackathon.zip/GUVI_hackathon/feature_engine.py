import librosa
import numpy as np

def extract_features(file_path):
    y, sr = librosa.load(file_path, sr=None)

    mfcc = np.mean(librosa.feature.mfcc(y=y, sr=sr), axis=1)
    pitch = np.std(librosa.yin(y, fmin=50, fmax=300))
    spectral_flatness = np.mean(librosa.feature.spectral_flatness(y=y))
    zero_crossing = np.mean(librosa.feature.zero_crossing_rate(y))
    energy = np.std(librosa.feature.rms(y=y))

    return np.hstack([
        mfcc,
        pitch,
        spectral_flatness,
        zero_crossing,
        energy
    ])