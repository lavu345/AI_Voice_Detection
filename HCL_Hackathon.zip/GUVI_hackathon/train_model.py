import os
import numpy as np
import joblib
from feature_engine import extract_features
from sklearn.ensemble import RandomForestClassifier

X = []
y = []

def load_data(folder, label):
    for file in os.listdir(folder):
        path = os.path.join(folder, file)
        features = extract_features(path)
        X.append(features)
        y.append(label)

load_data("dataset/human", 0)
load_data("dataset/ai", 1)

model = RandomForestClassifier(n_estimators=200)
model.fit(X, y)

joblib.dump(model, "model/classifier.pkl")

print("Model trained and saved!")