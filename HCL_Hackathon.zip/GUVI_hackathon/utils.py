import base64
import io
import os
from pydub import AudioSegment
from dotenv import load_dotenv

load_dotenv()

VALID_KEYS = os.getenv("API_KEYS").split(",")

def verify_key(key):
    return key in VALID_KEYS

def decode_audio(base64_audio):
    audio_bytes = base64.b64decode(base64_audio)
    audio = AudioSegment.from_file(io.BytesIO(audio_bytes), format="mp3")
    audio.export("temp.wav", format="wav")
    return "temp.wav"