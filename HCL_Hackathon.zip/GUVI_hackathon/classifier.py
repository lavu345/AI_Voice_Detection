import joblib
from feature_engine import extract_features

model = joblib.load("model/classifier.pkl")

def predict(file):
    features = extract_features(file)
    prob = model.predict_proba([features])[0][1]
    return prob

def explain(score):
    if score > 0.85:
        return "Highly stable pitch and waveform smoothing indicate synthetic speech"
    elif score > 0.6:
        return "Moderate artificial prosody patterns detected"
    else:
        return "Natural voice variation and harmonics indicate human speech"