from fastapi import FastAPI, HTTPException
import whisper
from utils import verify_key, decode_audio
from classifier import predict, explain

app = FastAPI()
whisper_model = whisper.load_model("base")

@app.post("/detect-voice")
def detect(payload: dict):
    if not verify_key(payload.get("api_key")):
        raise HTTPException(401, "Invalid API Key")

    wav_file = decode_audio(payload["audio_base64"])

    lang_result = whisper_model.transcribe(wav_file, task="detect_language")
    language = lang_result["language"]

    score = predict(wav_file)

    return {
        "classification": "AI Generated" if score > 0.5 else "Human",
        "confidence": round(float(score), 2),
        "language": language,
        "explanation": explain(score)
    }